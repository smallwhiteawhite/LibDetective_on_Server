import zipfile
import argparse
import shutil
import os
import json
import subprocess
import tlsh
import re
from collections import OrderedDict
import networkx as nx
import numpy as np
from numpy.linalg import norm
from tabulate import tabulate

# prefix
lib2func = '----'
lib2lib = '||||'


ctagsPath = '/usr/bin/ctags'

cflow_path = "/usr/bin/cflow"

current_path = os.getcwd() + '/LibDetectiveRepo'

target_source_code_path = current_path + '/target_source_code'

code_repo_path = target_source_code_path

componentDB_path = current_path + '/componentDB'

target_hidx_path = current_path + '/target_hidx'

target_json_path = current_path + '/target_json'

resultPath		= current_path + "/res/"

top50_json_path = current_path + "/top50_json"

top50_list_file_path = top50_json_path

cflow_result_path = current_path + "/cflow_result"

fcg_repo_path = current_path + '/fcg_repo'

func_fcg_repo_path = current_path + '/func_fcg_repo'


file_fcg_repo_path = current_path + '/file_fcg_repo'

target_fcg_repo_path = file_fcg_repo_path

sor_file_fcg_repo_path = current_path + '/sor_file_fcg_repo'

sor_func_fcg_repo_path = current_path + '/sor_func_fcg_repo'

fcg_nodes_repo_path = current_path + '/fcg_nodes_repo'

fcg_nodes_repo_path = current_path + '/fcg_nodes_repo'

def init():
    if os.path.exists(target_source_code_path):
        shutil.rmtree(target_source_code_path)
    if os.path.exists(target_hidx_path):
        shutil.rmtree(target_hidx_path)
    os.mkdir(target_hidx_path)
    if os.path.exists(resultPath):
        shutil.rmtree(resultPath)
    os.mkdir(resultPath)
    if os.path.exists(top50_json_path):
        shutil.rmtree(top50_json_path)
    os.mkdir(top50_json_path)
    if os.path.exists(fcg_repo_path):
        shutil.rmtree(fcg_repo_path)
    os.mkdir(fcg_repo_path)
    if os.path.exists(file_fcg_repo_path):
        shutil.rmtree(file_fcg_repo_path)
    os.mkdir(file_fcg_repo_path)
    if os.path.exists(func_fcg_repo_path):
        shutil.rmtree(func_fcg_repo_path)
    os.mkdir(func_fcg_repo_path)
    if os.path.exists(cflow_result_path):
        shutil.rmtree(cflow_result_path)
    os.mkdir(cflow_result_path)
    if os.path.exists(fcg_nodes_repo_path):
        shutil.rmtree(fcg_nodes_repo_path)
    os.mkdir(fcg_nodes_repo_path)
    if os.path.exists(target_json_path):
        shutil.rmtree(target_json_path)
    os.mkdir(target_json_path)

def unzip_file(zip_file, extract_to=target_source_code_path):
    with zipfile.ZipFile(zip_file, 'r') as zip_ref:
        zip_ref.extractall(extract_to)
        return True
    return False

def get_libname_from_parser():
    parser = argparse.ArgumentParser(description="LibDetective")
    parser.add_argument("target_lib", type=str, help="input the name of target lib")
    args = parser.parse_args()
    lib = args.target_lib
    return lib

def computeTlsh(string):
    string = str.encode(string)
    hs = tlsh.forcehash(string)
    return hs

def removeComment(string):
    # Code for removing C/C++ style comments. (Imported from VUDDY and ReDeBug.)
    # ref: https://github.com/squizz617/vuddy
    c_regex = re.compile(
        r'(?P<comment>//.*?$|[{}]+)|(?P<multilinecomment>/\*.*?\*/)|(?P<noncomment>\'(\\.|[^\\\'])*\'|"(\\.|[^\\"])*"|.[^/\'"]*)',
        re.DOTALL | re.MULTILINE)
    return ''.join([c.group('noncomment') for c in c_regex.finditer(string) if c.group('noncomment')])

def normalize(string):
    # Code for normalizing the input string.
    # LF and TAB literals, curly braces, and spaces are removed,
    # and all characters are lowercased.
    # ref: https://github.com/squizz617/vuddy
    return ''.join(string.replace('\n', '').replace('\r', '').replace('\t', '').replace('{', '').replace('}', '').split(
        ' ')).lower()

def hashing(repoPath):
    # This function is for hashing C/C++ functions
    # Only consider ".c", ".cc", and ".cpp" files
    possible = (".c", ".cc", ".cpp")

    fileCnt = 0
    funcCnt = 0
    lineCnt = 0

    resDict = {}

    for path, dir, files in os.walk(repoPath):
        for file in files:
            filePath = os.path.join(path, file)

            if file.endswith(possible):
                try:
                    # Execute Ctgas command
                    functionList = subprocess.check_output(
                        ctagsPath + ' -f - --kinds-C=* --fields=neKSt "' + filePath + '"', stderr=subprocess.STDOUT,
                        shell=True).decode()
                    # print(functionList)
                    # print('*****************************')
                    f = open(filePath, 'r', encoding="UTF-8")

                    # For parsing functions
                    lines = f.readlines()
                    allFuncs = str(functionList).split('\n')
                    func = re.compile(r'(function)')

                    number = re.compile(r'(\d+)')
                    funcSearch = re.compile(r'{([\S\s]*)}')
                    tmpString = ""
                    funcBody = ""

                    fileCnt += 1

                    for i in allFuncs:
                        elemList = re.sub(r'[\t\s ]{2,}', '', i)
                        elemList = elemList.split('\t')
                        funcBody = ""

                        if i != '' and len(elemList) >= 8 and func.fullmatch(elemList[3]):
                            funcName = elemList[0]
                            funcStartLine = int(number.search(elemList[4]).group(0))
                            funcEndLine = int(number.search(elemList[7]).group(0))

                            tmpString = ""
                            tmpString = tmpString.join(lines[funcStartLine - 1: funcEndLine])

                            if funcSearch.search(tmpString):
                                funcBody = funcBody + funcSearch.search(tmpString).group(1)
                            else:
                                funcBody = " "

                            funcBody = removeComment(funcBody)
                            funcBody = normalize(funcBody)
                            funcHash = computeTlsh(funcBody)
                            if len(funcHash) == 72 and funcHash.startswith("T1"):
                                funcHash = funcHash[2:]
                            elif funcHash == "TNULL" or funcHash == "" or funcHash == "NULL":
                                continue

                            storedPath = filePath.replace(repoPath, "")
                            if funcHash not in resDict:
                                resDict[funcHash] = []
                            if funcName in resDict[funcHash]:
                                resDict[funcHash][-1] = storedPath
                            else:
                                resDict[funcHash].append(storedPath)
                            resDict[funcHash].append(funcName)

                            lineCnt += len(lines)
                            funcCnt += 1

                except subprocess.CalledProcessError as e:
                    print("Parser Error:", e)
                    continue
                except Exception as e:
                    print("Subprocess failed", e)
                    continue

    return resDict, fileCnt, funcCnt, lineCnt

def indexing(resDict, title, filePath):
    # For indexing each OSS

    fres = open(filePath, 'w')
    fres.write(title + '\n')

    for hashval in resDict:
        if hashval == '' or hashval == ' ':
            continue

        fres.write(hashval)

        for funcPath in resDict[hashval]:
            fres.write('\t' + funcPath)
        fres.write('\n')

    fres.close()

def get_target_hidx():
    for input_folder in os.listdir(target_source_code_path):
        repoName = input_folder
        resDict, fileCnt, funcCnt, lineCnt = hashing(os.path.join(target_source_code_path, input_folder))
        if len(resDict) > 0:
            title = '\t'.join([repoName, str(fileCnt), str(funcCnt), str(lineCnt)])
            resultFilePath = target_hidx_path + '/' + repoName + '_fuzzy' + '.hidx'
            indexing(resDict, title, resultFilePath)

def resloveTargetHidx():
    for file in os.listdir(target_hidx_path):
        temp = file.split('_')[0]
        idx = temp.rfind('-')
        targetName = temp[:idx]
        version = temp[idx+1:]
        # print(targetName, version)
        file_path = os.path.join(target_hidx_path, file)
        with open(file_path, "r") as fp:
            content = fp.read()
        fp.close()
        lines = content.split('\n')
        del lines[0], lines[-1]
        funcInfos = []
        for line in lines:
            content = line.split('\t')
            hashVal = content[0]
            names = []
            for i in range(1, len(content)):
                if content[i][0] != '/':
                    names.append(content[i])
            funcInfo = [hashVal, names]
            funcInfos.append(funcInfo)
        with open(target_json_path + '/' + targetName + ".json", "w") as f:
            json.dump(funcInfos, f, indent=4)

def computeScore(hashVal1, hashVal2):
    score = tlsh.diffxlen(hashVal1, hashVal2)
    similarity = score/256
    if similarity > 1:
        similarity = 0.99
    return similarity

def findMaxKey(matchDict):
    maxVal = max(matchDict.values())
    max_key = [key for key, value in matchDict.items() if value == maxVal]
    return max_key[0]

def compareAllOSS(target_file_name, hash_names_list):
    hashVal = hash_names_list[0]
    names_list = hash_names_list[1]
    # print(names_list)
    matchDict = {}
    oss_content = []
    for OSS in os.listdir(componentDB_path):
        oss_path = os.path.join(componentDB_path, OSS)
        with open(oss_path, "r") as of:
            new_oss_content = json.load(of)
        oss_content = oss_content + new_oss_content
    for line in oss_content:
        osshashVal = line[0]
        oss_func_names_list = line[1]
        oss_name = line[2].split("@@")[1]
        similarity = computeScore(hashVal, osshashVal)
        if len(matchDict) < 50:
            for i in range(0, len(names_list)):
                for j in range(0, len(oss_func_names_list)):
                    key = target_file_name + lib2func + names_list[i] + lib2lib + oss_name + lib2func + oss_func_names_list[j]
                    matchDict[key] = similarity
        else:
            maxKey = findMaxKey(matchDict)
            maxVal = matchDict[maxKey]
            if similarity >= maxVal:
                pass
            else:
                matchDict.pop(maxKey)
                for i in range(0, len(names_list)):
                    for j in range(0, len(oss_func_names_list)):
                        key = target_file_name + lib2func + names_list[i] + lib2lib + oss_name + lib2func + oss_func_names_list[j]
                        matchDict[key] = similarity
    matchDict = OrderedDict(sorted(matchDict.items(), key=lambda x: x[1]))
    if len(matchDict) > 50:
        matchDict = dict(list(matchDict.items())[:50])
    for i in range(0, len(names_list)):
        if os.path.exists(resultPath + target_file_name + "_reuse_func_dict_" + names_list[i] + ".json"):
            pass
        else:
            with open(resultPath + target_file_name + "_reuse_func_dict_" + names_list[i] + ".json", "w") as f:
                if len(matchDict) != 50:
                    pass
                    # print("the length of matchDict is " + str(len(matchDict)))
                json.dump(matchDict, f)

def getTop50Funcs():
    for target_file in os.listdir(target_json_path):
        target_file_name = target_file.replace(".json", "")
        target_file_path = os.path.join(target_json_path, target_file)
        with open(target_file_path, "r") as tf:
            target_content = json.load(tf)
        for line in target_content:
            compareAllOSS(target_file_name, line)

def composeDicts():
    json_files = []
    for file in os.listdir(resultPath):
        json_files.append(os.path.join(resultPath, file))
    lib_name = json_files[0].split("_reuse_")[0].split("res/")[1] + "_reuse_func_dict"
    all_data = {}
    for file_path in json_files:
        with open(file_path, 'r') as file:
            data = json.load(file)
            all_data.update(data)
    with open(top50_json_path + '/' + lib_name + '.json', 'w') as outfile:
        json.dump(all_data, outfile, indent=None)

def count_depth(s):
    first_non_space_index = s.index(s.strip()[0])
    leading_spaces_count = s[:first_non_space_index].count(' ')
    return leading_spaces_count

def c_flow_parser(command, txt_name, txt_new_folder):
    try:
        result = subprocess.check_output(command, stderr=subprocess.STDOUT, text=True, encoding="utf-8")
        with open(txt_new_folder + '/' + txt_name, "w") as f:
            f.write(result)
            return True
    except subprocess.CalledProcessError as e:
        print("Error executing cflow: ", e.output)
        return False

def C_FCG_Generator(txt_name, txt_new_folder, fcg_new_folder, file_path):
    try:
        with open(txt_new_folder + '/' + txt_name, 'r', encoding='utf-8') as file:
            name_prefix = txt_name.replace('.txt', '')
            fathers = []
            for line in file:
                if line[0] != ' ':
                    if line[0] == '/':
                        pass
                    else:
                        # if the first time
                        if len(fathers) == 0:
                            root_node = line.split("(")[0]
                            fathers.append(root_node)
                            fcg = nx.DiGraph()
                            fcg.add_node(root_node)
                        else:
                            nx.write_gml(fcg, fcg_new_folder + '/' + name_prefix + '@' + fathers[0] + '.gml')
                            root_node = line.split("(")[0]
                            fathers[0] = root_node
                            fcg = nx.DiGraph()
                            fcg.add_node(root_node)
                else:
                    depth = int(count_depth(line)/4)
                    new_node = line.split("(")[0].replace(' ', '')
                    fcg.add_node(new_node)
                    fcg.add_edge(fathers[depth-1], new_node)
                    if len(fathers) == depth:
                        fathers.append(new_node)
                    else:
                        fathers[depth] = new_node
            nx.write_gml(fcg, fcg_new_folder + '/' + name_prefix + '@' + fathers[0] + ".gml")
    except FileNotFoundError:
        print("file not found!")
    except Exception as e:
        with open(current_path + "/failed_files.txt", "a+") as f:
            f.write(file_path + '\n')
        # print("no function definition in target file, result to (", e, ") error")

def generate_c_fcg_1():
    for lib in os.listdir(code_repo_path):
        if os.path.isdir(code_repo_path + '/' + lib):
            txt_new_folder = cflow_result_path + '/' + lib
            if os.path.exists(txt_new_folder):
                pass
            else:
                os.mkdir(txt_new_folder)
            fcg_new_folder = fcg_repo_path + '/' + lib
            if os.path.exists(fcg_new_folder):
                pass
            else:
                os.mkdir(fcg_new_folder)
            lib_path = code_repo_path + '/' + lib
            for root, dirs, files in os.walk(lib_path):
                for file in files:
                    if file.endswith('.c'):
                        file_path = os.path.join(root, file)
                        file_name = file_path.replace(lib_path, "").replace('/', '_')
                        # print(file_name)
                        txt_name = file_name.strip(".c") + ".txt"
                        command = [cflow_path, file_path]
                        if c_flow_parser(command, txt_name, txt_new_folder):
                            C_FCG_Generator(txt_name, txt_new_folder, fcg_new_folder, file_path)

def generate_c_fcg_2():
    for lib in os.listdir(fcg_repo_path):
        lib_path = os.path.join(func_fcg_repo_path, lib)
        if os.path.exists(lib_path):
            pass
        else:
            os.mkdir(lib_path)
        fcg_lib_path = lib_path.replace("func_fcg_repo", "fcg_repo")
        acc_lists = []
        for source_fcg in os.listdir(fcg_lib_path):
            source_fcg_path = os.path.join(fcg_lib_path, source_fcg)
            old_source_fcg = nx.read_gml(source_fcg_path)
            root = [node for node in old_source_fcg.nodes() if old_source_fcg.in_degree(node) == 0]
            find = False
            for acc_list in acc_lists:
                find = False
                if acc_list[0] == root:
                    acc_list.append(source_fcg_path)
                    find = True
                    break
            if find == False:
                root_and_path = [root, source_fcg_path]
                acc_lists.append(root_and_path)

        for file in os.listdir(fcg_lib_path):
            file_path = os.path.join(fcg_lib_path, file)
            old_fcg = nx.read_gml(file_path)
            new_fcg_path = file_path.replace("fcg_repo", "func_fcg_repo")
            leaves = [node for node in old_fcg.nodes() if old_fcg.out_degree(node) == 0]
            for leaf in leaves:
                for acc_list in acc_lists:
                    if acc_list[0] == leaf:
                        add_fcg = nx.read_gml(acc_list[1])
                        old_fcg = nx.compose(old_fcg, add_fcg)
            new_fcg = old_fcg
            nx.write_gml(new_fcg, new_fcg_path)

def compose_fcgs():
    for dir in os.listdir(func_fcg_repo_path):
        lib_name = dir
        lib_path = os.path.join(fcg_repo_path, lib_name)
        file_fcg = nx.DiGraph()
        file_fcg.add_node(lib_name)
        for file in os.listdir(lib_path):
            fcg_name = file.replace(".gml", "")[1:]
            fcg_path = os.path.join(lib_path, file)
            func_fcg = nx.read_gml(fcg_path)
            root = [node for node, degree in func_fcg.in_degree() if degree == 0][0]
            if root == "main":
                func_fcg = nx.relabel_nodes(func_fcg, {root: fcg_name})
                root = fcg_name
            else:
                pass
            file_fcg = nx.compose(file_fcg, func_fcg)
            file_fcg.add_edge(lib_name, root)
        nx.write_gml(file_fcg, os.path.join(file_fcg_repo_path, lib_name) + '.gml')

def end_work(leave_fcg_repo = True, leave_cflow_result = True, leave_func_fcg_repo = True):
    if leave_cflow_result:
        pass
    else:
        shutil.rmtree(cflow_result_path)
    if leave_fcg_repo:
        pass
    else:
        shutil.rmtree(fcg_repo_path)
    if leave_func_fcg_repo:
        pass
    else:
        shutil.rmtree(func_fcg_repo_path)

def getNodeList():
    for fcg_name in os.listdir(sor_file_fcg_repo_path):
        new_file_name = fcg_name.replace(".gml", ".json")
        fcg_path = os.path.join(sor_file_fcg_repo_path, fcg_name)
        fcg = nx.read_gml(fcg_path)
        fcg_nodes = fcg.nodes()
        # print(fcg_nodes)
        filtered_nodes = [node for node in fcg_nodes if '@' not in node]
        with open(os.path.join(fcg_nodes_repo_path, new_file_name), 'w') as ff:
            json.dump(filtered_nodes, ff)
        ff.close()

def getAnchorPairList():
    i = 0
    for tarfile in os.listdir(target_fcg_repo_path):
        # print(os.path.join(target_fcg_repo_path, tarfile))
        # temp = tarfile.replace(".gml", '')
        # if '.' in temp:
        #     temp.replace('.', '-')
        #     temp = temp + ".gml"
        #     os.rename(os.path.join(target_fcg_repo_path, tarfile), os.path.join(target_fcg_repo_path, temp))
        #     tarfile = temp
        with open(os.path.join(target_fcg_repo_path, tarfile)) as f:
            # print(os.path.join(target_fcg_repo_path, tarfile))
            target_fcg = nx.read_gml(os.path.join(target_fcg_repo_path, tarfile))
            target_nodes = target_fcg.nodes()
            target_nodes = [node for node in target_nodes if '@' not in node]
        f.close()
    for jsonfile in os.listdir(top50_list_file_path):
        with open(os.path.join(top50_list_file_path, jsonfile)) as f:
            data = json.load(f)
            data_list = list(data.items())
            all_list = []
            target_in_nodes = []
            for item in data_list:
                tarFunc = item[0].split("||||")[0].split("----")[1]
                tarLib = item[0].split("----")[0]
                sorFunc = item[0].split("----")[2]
                sorLib = item[0].split("||||")[1].split("----")[0]
                listname = tarLib + "--->" + sorLib
                if tarFunc in target_in_nodes:
                    for node_file in os.listdir(fcg_nodes_repo_path):
                        if sorLib in node_file:
                            with open(os.path.join(fcg_nodes_repo_path, node_file), 'r') as f:
                                nodes = json.load(f)
                            f.close()
                            if sorFunc in nodes:
                                find = False
                                for one_list in all_list:
                                    if one_list[0] == listname:
                                        one_list.append([tarFunc, sorFunc])
                                        find = True
                                if find == False:
                                    all_list.append([listname, [tarFunc, sorFunc]])
                                i = i + 1
                else:
                    if tarFunc in target_nodes:
                        target_in_nodes.append(tarFunc)
                        for node_file in os.listdir(fcg_nodes_repo_path):
                            if sorLib in node_file:
                                with open(os.path.join(fcg_nodes_repo_path, node_file), 'r') as f:
                                    nodes = json.load(f)
                                f.close()
                                if sorFunc in nodes:
                                    find = False
                                    for one_list in all_list:
                                        if one_list[0] == listname:
                                            one_list.append([tarFunc, sorFunc])
                                            find = True
                                    if find == False:
                                        all_list.append([listname, [tarFunc, sorFunc]])
                                    i = i + 1
    # print(i)
    # for A in all_list:
    #     print(A[0], len(A))
    with open(current_path + '/all_list.json', 'w') as f:
        json.dump(all_list, f)
    f.close()

def get_base_vector(G):
    degree = dict(G.degree)
    deg = {}
    for item in degree:
        if degree[item] not in deg:
            deg[degree[item]] = 1
        if degree[item] in deg:
            deg[degree[item]] = deg[degree[item]] + 1
    sorted_dict = dict(sorted(deg.items()))
    deg_list = sorted_dict.values()

    vector = np.array(list(deg_list))
    return vector / norm(vector)

def resize_vectors(v1, v2):
    max_dim = max(len(v1), len(v2))

    # 将向量扩展到相同的维度
    nv1 = np.pad(v1, (0, max_dim - len(v1)))
    nv2 = np.pad(v2, (0, max_dim - len(v2)))
    return nv1, nv2

def resloveAllFiles():
    with open(current_path + '/all_list.json', 'r') as f:
        content = json.load(f)
    f.close()
    for A in content:
        # print("*******************")
        target_file = A[0].split("--->")[0]
        source_file = A[0].split("--->")[1]
        # print(target_file, source_file)
        for pair in A[1:]:
            tarFunc = pair[0]
            sorFunc = pair[1]
            find = 0
            for tarfuncfcgfolder in os.listdir(func_fcg_repo_path):
                # print("**********")
                # print(target_file, tarfuncfcgfolder.split("@@")[1])
                idx = tarfuncfcgfolder.rfind('-')
                if target_file == tarfuncfcgfolder[:idx]:
                    for tarfuncfcg in os.listdir(os.path.join(func_fcg_repo_path, tarfuncfcgfolder)):
                        if tarFunc in tarfuncfcg:
                            tar_fcg = nx.read_gml(os.path.join(func_fcg_repo_path, tarfuncfcgfolder, tarfuncfcg))
                            find = 1
                            break
            if find:
                for sorfuncfcgfolder in os.listdir(sor_func_fcg_repo_path):
                    if source_file == sorfuncfcgfolder.split("@@")[1]:
                        for sorfuncfcg in os.listdir(os.path.join(sor_func_fcg_repo_path, sorfuncfcgfolder)):
                            if sorFunc in sorfuncfcg:
                                with open(current_path + "/result.txt", "a+") as f:
                                    sor_fcg = nx.read_gml(os.path.join(sor_func_fcg_repo_path, sorfuncfcgfolder, sorfuncfcg))
                                    # print('working', tar_fcg, sor_fcg)
                                    tar_norm_vec = get_base_vector(tar_fcg)
                                    sor_norm_vec = get_base_vector(sor_fcg)
                                    ntarv, nsorv = resize_vectors(tar_norm_vec, sor_norm_vec)
                                    similarity = np.dot(ntarv, nsorv)
                                    similarity = similarity * min(len(tar_fcg), len(sor_fcg)) /\
                                                 (len(tar_fcg) + len(sor_fcg))
                                    # max_shared_subgraph = isomorphism.GraphMatcher(tar_fcg, sor_fcg, node_match=node_match)

                                    # str_tar = str(sorted(tar_fcg.edges()))
                                    # str_sor = str(sorted(sor_fcg.edges()))
                                    # edit_distance = nx.graph_edit_distance(tar_fcg, sor_fcg, node_match=node_match)
                                    # edit_distance = nx.graph_edit_distance(tar_fcg, sor_fcg)
                                    # print(tarFunc, sorFunc, similarity, len(tar_fcg.nodes()), len(sor_fcg.nodes))
                                    f.write(tarFunc + '\t' + sorFunc + '\t' + str(similarity) + '\t' + str(len(tar_fcg.nodes())) + '\t' + str(len(sor_fcg.nodes)) + '\t'  + source_file + '\n')


                                f.close()
                                # if (len(tar_fcg.nodes()) / len(sor_fcg.nodes)) >= 2 or (len(tar_fcg.nodes()) / len(sor_fcg.nodes)) <= 0.5:
                                #     pass
                                # elif abs((len(tar_fcg.nodes()) - len(sor_fcg.nodes))) > 6:
                                #     pass
                                # else:
                                #     with open("result.txt" , "a+") as f:
                                #
                                #         edit_distance = distance(str_tar, str_sor) / (
                                #             len(tar_fcg.nodes()) + len(sor_fcg.nodes))
                                #         print(tarFunc, sorFunc, edit_distance, len(tar_fcg.nodes()), len(sor_fcg.nodes))
                                #         f.write(tarFunc + '\t' + sorFunc + '\t' + str(edit_distance) + '\t' +
                                #                 str(len(tar_fcg.nodes())) + '\t' + str(len(sor_fcg.nodes)) + '\t'
                                #                 + source_file + '\n')
                                #     f.close()
                                break

def beautify_result(lib):
  # 读取文本文件中的数据
   with open(current_path + '/result.txt', 'r') as f:
       data = [line.strip().split('\t') for line in f]

   headers = ['targetFunction', 'sourceFunction', 'cosineSimilarity', 'targetNodeNums', 'sourceNodesNum', 'sourceLib']

   table = tabulate(data, headers=headers, tablefmt='grid')
   print(lib+'_result.txt')
   with open(lib + '_result.txt', 'w') as f:
       f.write(table)

def delete_useless():
    save = ["componentDB", "sor_file_fcg_repo", "sor_func_fcg_repo", "LibDetective.py",
            "beautified_result.txt"]
    for file in os.listdir(current_path):
        if file not in save:
            if os.path.isdir(os.path.join(current_path, file)):
                shutil.rmtree(os.path.join(current_path, file))
            else:
                os.remove(os.path.join(current_path, file))


def detect_libraries(lib):

    init()

    # lib = get_libname_from_parser()

    is_succeed = unzip_file(lib)

    if is_succeed:
        get_target_hidx()

        resloveTargetHidx()

        getTop50Funcs()

        composeDicts()

        generate_c_fcg_1()

        generate_c_fcg_2()

        compose_fcgs()

        end_work(False, False, True)

        getNodeList()

        getAnchorPairList()

        resloveAllFiles()

        beautify_result(lib.replace(".zip", "").split("/")[-1])

        delete_useless()


    else:

        print("please check the input file name")

        exit(0)




